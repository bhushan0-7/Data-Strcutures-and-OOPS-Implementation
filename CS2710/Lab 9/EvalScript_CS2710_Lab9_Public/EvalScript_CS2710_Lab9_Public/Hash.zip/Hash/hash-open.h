typedef int ElementType;
typedef enum {Linear, Quadratic, Double} OAType;

class HashTable {
public:
	HashTable(OAType type = Linear, int H = 19);
	bool insert(ElementType e);
	bool remove(ElementType e);
	bool find(ElementType e);
	void print();
	int size();	// number of elements.
private:
	int H;
	ElementType *arr;
	OAType type;

	static const int emptycell = -1;
	static const int deletedcell = -2;
	int ncolli;
	

	int hash(ElementType e);
	int hashTwo(ElementType e);
	int nextIndex(ElementType e, int oriIndex = -1, int ii = 0);
};


