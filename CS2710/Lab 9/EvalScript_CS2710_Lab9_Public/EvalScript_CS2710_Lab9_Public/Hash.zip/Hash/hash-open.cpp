#include <iostream>
#include <sys/time.h>
#include <stdlib.h>
#include "hash-open.h"

int HashTable::hash(ElementType e) {
	// assumes char or int.
	return (int)e % H;
}
int HashTable::hashTwo(ElementType e) {
	return ((int)e % (H / 2)) % (H - 1) + 1;	// ensures non-zero.
}
void HashTable::print() {
	for (int ii = 0; ii < H; ++ii) {
		std::cout << ii << ": " << arr[ii] << std::endl;
	}
	std::cout << "Number of collisions = " << ncolli << std::endl;
}
HashTable::HashTable(OAType type /* = Linear*/, int H /*= 19*/) {
	this->H = H;
	this->type = type;
	ncolli = 0;
	arr = new ElementType[H];
	for (int ii = 0; ii < H; ++ii)
		arr[ii] = emptycell;
	std::cout << "Created hashtable of size " << H << std::endl;
}
int HashTable::nextIndex(ElementType e, int oriIndex /*= -1*/, int ii /*= 0*/) {
	if (ii == 0) return hash(e);
	if (type == Linear) return (oriIndex + ii) % H;
	if (type == Quadratic) return (oriIndex + ii * ii) % H;
	if (type == Double) return (oriIndex + ii * hashTwo(e)) % H;
	std::cerr << "Wrong open addressing type.\n";
}
bool HashTable::insert(ElementType e) {
	if (e < 0) {
		std::cout << "Only positive integers are allowed.\n";
		return false;
	}

	int oriIndex = nextIndex(e);
	int index = oriIndex;

	for (int ii = 0; ii < H; ++ii) {
		if (arr[index] == emptycell) {
			arr[index] = e;
			std::cout << e << " inserted at index " << index << std::endl;
			return true;
		} else {
			++ncolli;
		}
		index = nextIndex(e, oriIndex, ii);
	}
	std::cerr << "Hashtable is full. Unable to insert " << e << std::endl;
	// alternatively, maintain a counter with the hashtable, to avoid going through it when full.
	return false;
}
bool HashTable::remove(ElementType e) {
	int oriIndex = nextIndex(e);
	int index = oriIndex;

	for (int ii = 0; ii < H; ++ii) {
		if (arr[index] == e) {
			arr[index] = deletedcell;
			std::cout << e << " deleted from index " << index << std::endl;
			return true;	// assumes unique keys.
		} else if (arr[index] == emptycell) {
			std::cout << e << " not present in hashtable (early exit).\n";
			return false;
		} // else if it is deleted or another element, keep searching.
		index = nextIndex(e, oriIndex, ii);
	}
	std::cerr << e << " not present in hashtable.\n";
	return false;
}
bool HashTable::find(ElementType e) {
	int oriIndex = nextIndex(e);
	int index = oriIndex;

	for (int ii = 0; ii < H; ++ii) {
		if (arr[index] == e) {
			std::cout << e << " is found at index " << index << std::endl;
			return true;
		} else if (arr[index] == emptycell) {
			std::cout << e << " not present in hashtable (early exit).\n";
			return false;
		} // else if it is deleted or another element, keep searching.
		index = nextIndex(e, oriIndex, ii);
	}
	std::cerr << e << " not present in hashtable.\n";
	
	return false;
}
int main() {
	HashTable ht(Double, 7);

	/*srand(time(NULL));

	for (int ii = 0; ii < 10; ++ii) {
		ElementType e = rand() % 100;
		std::cout << "inserting " << (int)e << std::endl;
		ht.insert(e);
	}*/
	ht.insert(4);
	ht.insert(12);
	ht.insert(70);
	ht.insert(11);
	ht.insert(20);
	ht.print();

	ht.remove(5);
	ht.remove(4);
	ht.remove(11);
	ht.remove(1);
	ht.print();

	ht.find(3);
	ht.find(4);
	ht.find(12);
	ht.find(11);
	ht.print();

	return 0;
}
